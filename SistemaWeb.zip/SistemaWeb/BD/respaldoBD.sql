-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
DROP DATABASE IF EXISTS `sistemaweb`;
CREATE SCHEMA IF NOT EXISTS `sistemaweb` DEFAULT CHARACTER SET utf8 ;
USE `sistemaweb` ; 

-- -----------------------------------------------------
-- Table `mydb`.`Alumno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Alumno` (
  `idAlum` INT NOT NULL auto_increment,
  `Nombre` VARCHAR(45) NOT NULL,
  `Apellido` VARCHAR(45) NOT NULL,
  `Correo` VARCHAR(45) NOT NULL,
  `Contra` VARCHAR(75) NOT NULL,
  `FechaNa` DATE NOT NULL,
  `Genero` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idAlum`))
ENGINE = InnoDB;
INSERT INTO alumno VALUES
("1","Maximiliano","Diaz","max@gmail.com","max","2000-05-20","Masculino"),
("4","Alondra","Portillo","alondra@gmail.com","$2y$10$Ax1TYGC.KneBauQcZZgZW.vhdjq5cB7GGuGhGkYdWOZC5Oh60Pl9S","2012-02-20","Femenino"),
("6","Eduardo","Lopez","Elopez@mail.com","$2y$10$VerfiaDfPJ.xzxwweO9b4O9j86GrCNQevWFGbBq4lLQA12BkJ7aPu","2001-01-01","Masculino"),
("9"," Pedro","Diaz","pedro@gmail.com","$2y$10$aM.7HzaO9L1JsxqNR8KNmOQlz2jBmpoMz99E1XgBYJWuAy16rq5am","2003-08-30","Masculino");

-- -----------------------------------------------------
-- Table `mydb`.`Encuesta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Encuesta` (
  `idEnc` INT NOT NULL,
  `Pregunta` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idEnc`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`Asignar`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Asignar` (
  `idAsig` INT auto_increment,
  `FechaEn` DATE NOT NULL,
  `idAlum` INT NULL,
  `idEnc` INT NULL,
  PRIMARY KEY (`idAsig`),
    FOREIGN KEY (`idEnc`)
    REFERENCES `sistemaweb`.`Encuesta` (`idEnc`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    FOREIGN KEY (`idAlum`)
    REFERENCES `sistemaweb`.`Alumno` (`idAlum`)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`Coordinador`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Coordinador` (
  `idCoor` INT auto_increment,
  `Nom` VARCHAR(45) NOT NULL,
  `Ape` VARCHAR(45) NOT NULL,
  `Cor` VARCHAR(45) NOT NULL,
  `Password` VARCHAR(45) NOT NULL,
  `Fecha` DATE NOT NULL,
  `Sexo` VARCHAR(45) NOT NULL,
  `Estatus` INT NULL,
  PRIMARY KEY (`idCoor`))
ENGINE = InnoDB;
INSERT INTO coordinador VALUES
("1","Sonia Paloma","Chvez","CSonia@gmail.com","$2y$10$jvWswxOyKrU78gdFelocQ.5UXjOFQgbuPR7Ayx","2002-02-12","Masculino","0"),
("2","Lucia","Mojica","GLucia@emial.com","$2y$10$uHbqIYTJVK2aWedmQ3Toz.p1BbH2S//jwSpAtJ","2000-12-12","Masculino","0"),
("3","jose","Vargad","Jose\"gmail.com","$2y$10$6smNDUQlECoYP6v3AMRYWOsERFLLABz4as6Cnb","2000-05-12","Masculino","0"),
("4","Jose","Vargas","Jose@gmail.com","$2y$10$6smNDUQlECoYP6v3AMRYWOsERFLLABz4as6Cnb","2000-05-12","Masculino","0"),
("5","Alondra ","Zagal","alondra@gmail.com","$2y$10$40gn23d3HGbyV4jWHiJE6uFXmuUwUFM86YR4eW","2000-02-12","Masculino","0");

-- -----------------------------------------------------
-- Table `mydb`.`Receta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Receta` (
  `idRec` INT auto_increment,
  `Titulo` VARCHAR(45) NOT NULL,
  `Contenido` TEXT NOT NULL,
  `Multimedia` TEXT NULL,
  `FechaPub` DATETIME NOT NULL,
  `Estatus` INT NULL,
  `idAlum` INT NULL,
  PRIMARY KEY (`idRec`),
    FOREIGN KEY (`idAlum`)
    REFERENCES `sistemaweb`.`Alumno` (`idAlum`)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB; 	
INSERT INTO receta VALUES
("1","Papas con queso","Ingredientes <br>
\nPapas","../../../IMG/papas.jpg","2023-11-09 12:25:15","1","1"),
("2","Enchiladas de mole","Ingredientes<br>
\nnull 4 1/2 tazas de caldo de pollo<br>
\n1 taza de aceite vegetal<br>
\n12 tortillas<br>
\n2 tazas de pollo cocido y deshebrado<br>
\n1 taza de crema","../../../IMG/enmoladas.jpg","2023-11-12 21:59:20","1","4"),
("15","Costillas a la BBQ","Ingredientes:
\nSalsa BBQ"," ","2023-11-14 14:47:15","1","6"),
("16","Chilaquiles","Ingredeintes: <br>2 Pieza de ajo<br>
\n1/4 Pieza de cebolla<br>
\n4 Piezas de tomate (jitomate)<br>
\n2 Piezas de chile guajillo<br>
\n2 Tazas de caldo de pollo"," ../../../IMG/chilaquiles.jpg","2023-11-14 19:47:17","0","6");
-- -----------------------------------------------------
-- Table `mydb`.`Respuesta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Respuesta` (
  `idRes` INT auto_increment,
  `Resultado` VARCHAR(45) NOT NULL,
  `Grado` VARCHAR(45) NOT NULL,
  `idAsig` INT NULL,
  PRIMARY KEY (`idRes`),
    FOREIGN KEY (`idAsig`)
    REFERENCES `sistemaweb`.`Asignar` (`idAsig`)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`Comentario`
-- -----------------------------------------------------
DROP TABLE IF EXISTS Comentario;
CREATE TABLE IF NOT EXISTS `sistemaweb`.`Comentario` (
  `idCom` INT auto_increment,
  `Comentario` TEXT NULL,
  `Calificacion` INT NULL,
  `idRec` INT NULL,
  `idAlum` INT NULL,
  PRIMARY KEY (`idCom`),
    FOREIGN KEY (`idRec`)
    REFERENCES `sistemaweb`.`Receta` (`idRec`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    FOREIGN KEY (`idAlum`)
    REFERENCES `sistemaweb`.`Alumno` (`idAlum`)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB;
INSERT INTO comentario VALUES
("1","Bueno",5,"16","1"),
("2","Excelente!!",5,"2","4"),
("3","Buena ",NULL,"2","6"),
("4","Nice",NULL,"2","6"),
("5","Nice",NULL,"16","6");


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;