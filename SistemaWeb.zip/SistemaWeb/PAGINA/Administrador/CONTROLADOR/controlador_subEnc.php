<?php
session_start();
include 'controlador_conexion.php';
//Obtener los datos para la encuesta
//if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['satisfaccion'])) {
        $p1 = $_POST['satisfaccion'];
        $p2 = $_POST['calidad'];
        $p3 = $_POST['facilidad'];
        $p4 = $_POST['calificacion'];
        $p5 = $_POST['compartir'];
    }

    //    echo $p1 .$p2 .$p3 .$p4. $p5;
    if (isset($_POST['comentarios'])) {
        $comentarios = $_POST['comentarios'];
    }else{
        $comentarios = "";            
    }
   // echo $comentarios;

    //obtener identificador alumno
    $cor = $_SESSION['usuario'];
  //  echo $cor;
    $sql = "SELECT IdAlum FROM alumno WHERE correo = '$cor'";
    $resultado = mysqli_query($enlace, $sql);
    $fila = mysqli_fetch_assoc($resultado);
    $idAlumno = $fila['IdAlum'];

   // echo "identidicador".$idAlumno;

    //obtener los identificadores para encuensta y respuesta 
    $sqlid = "SELECT Encuesta.idEnc AS Encuesta, Respuesta.idRes AS Respuesta from asignar
    INNER JOIN encuesta ON encuesta.idEnc = asignar.idEnc
    INNER JOIN respuesta ON respuesta.idAsig = asignar.idAsig 
    WHERE idAlum = '$idAlumno'";

    $resultadoI = mysqli_query($enlace, $sqlid);
    $fila = mysqli_fetch_assoc($resultadoI);
    $idEnc = $fila['Encuesta'];
    $idRes = $fila['Respuesta'];

   // echo "encuesta".$idEnc . "Respuesta" .$idRes;

    $sqlue = "UPDATE encuesta set pregunta = '$p1', pregunta2 = '$p2',
    pregunta3 = '$p3', pregunta4='$p4', pregunta5 = '$p5',
    comentarios ='$comentarios' WHERE idEnc = '$idEnc'";
    $excute = mysqli_query($enlace, $sqlue);

    if($excute){
        echo "se actualiza encuesta";
        $sqlur = "UPDATE respuesta set resultado = 1 WHERE idRes = '$idRes'";
        $excuteR = mysqli_query($enlace, $sqlur);
        if($excuteR){
            echo '<script>alert("Gracias por participar, tus respuestas nos ayudan a mejorar");
            window.location = "../VISTA/principal.php";</script>';
        }else{
            echo '<script>alert("Error al actualizar respuesta");
            window.location = "../VISTA/recetas.php";</script>';
        }
    }else{
        echo '<script>alert("Error al actualizar respuestas");
        window.location = "../VISTA/recetas.php";</script>';
    }
//}

?>