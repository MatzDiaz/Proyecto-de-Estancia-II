<?php
    include 'controlador_conexion.php';
    //ALUNMNOS POR HOMBRES Y MUJERES
    $sql = "SELECT COUNT(*) as total FROM alumno WHERE Genero = 'Masculino'";
    $query_masculino = mysqli_query($enlace, $sql);
    $resultado_masculino = mysqli_fetch_assoc($query_masculino);
    $masculino = $resultado_masculino['total'];
    
    $sql = "SELECT COUNT(*) as total FROM alumno WHERE Genero = 'Femenino'";
    $query_femenino = mysqli_query($enlace, $sql);
    $resultado_femenino = mysqli_fetch_assoc($query_femenino);
    $femenino = $resultado_femenino['total'];

    $sql = "SELECT COUNT(*) as total FROM receta
    INNER JOIN alumno on Receta.idAlum = Alumno.idAlum
    WHERE Genero = 'Masculino'";
    $query_masculino = mysqli_query($enlace, $sql);
    $resultado_masculino = mysqli_fetch_assoc($query_masculino);
    $rmasculino = $resultado_masculino['total'];
    
    $sql = "SELECT COUNT(*) as total FROM receta
    INNER JOIN alumno on Receta.idAlum = Alumno.idAlum
     WHERE Genero = 'Femenino'";
    $query_femenino = mysqli_query($enlace, $sql);
    $resultado_femenino = mysqli_fetch_assoc($query_femenino);
    $rfemenino = $resultado_femenino['total'];

    //RECETAS POR HOMBRES Y MUJERES
    $sql = "SELECT COUNT(*) as total FROM alumno WHERE Genero = 'Masculino'";
    $query_masculino = mysqli_query($enlace, $sql);
    $resultado_masculino = mysqli_fetch_assoc($query_masculino);
    $masculino = $resultado_masculino['total'];
    
    $sql = "SELECT COUNT(*) as total FROM alumno WHERE Genero = 'Femenino'";
    $query_femenino = mysqli_query($enlace, $sql);
    $resultado_femenino = mysqli_fetch_assoc($query_femenino);
    $femenino = $resultado_femenino['total'];


    //GRADO DE SATISFACCION
    $sql = "SELECT count(*) as total FROM encuesta WHERE pregunta = 2";
    $query_muyin = mysqli_query($enlace, $sql);
    $resultado_muyin= mysqli_fetch_assoc($query_muyin);
    $muyin = mysqli_num_rows($query_muyin) > 0 ? $resultado_muyin['total'] : 0;

    $sql = "SELECT count(*) as total FROM encuesta WHERE pregunta = 2";
    $query_insatisfecho = mysqli_query($enlace, $sql);
    $resultado_insatisfecho = mysqli_fetch_assoc($query_insatisfecho);
    $insatisfecho = mysqli_num_rows($query_insatisfecho) > 0 ? $resultado_insatisfecho['total'] : 0;

    $sql = "SELECT count(*) as total FROM encuesta WHERE pregunta = 3";
    $query_neutro = mysqli_query($enlace, $sql);
    $resultado_neutro = mysqli_fetch_assoc($query_neutro);
    $neutro = mysqli_num_rows($query_neutro) > 0 ? $resultado_neutro['total'] : 0;

    $sql = "SELECT count(*) as total FROM encuesta WHERE pregunta = 4";
    $query_satisfecho = mysqli_query($enlace, $sql);
    $resultado_satisfecho = mysqli_fetch_assoc($query_satisfecho);
    $satisfecho = mysqli_num_rows($query_satisfecho) > 0 ? $resultado_satisfecho['total'] : 0;

    $sql = "SELECT count(*) as total FROM encuesta WHERE pregunta = 5";
    $query_muysat = mysqli_query($enlace, $sql);
    $resultado_muysat = mysqli_fetch_assoc($query_muysat);
    $muysat = mysqli_num_rows($query_muysat) > 0 ? $resultado_muysat['total'] : 0;

    $sql = "SELECT Round(AVG(pregunta),2) as promedio FROM encuesta 
    INNER JOIN Asignar on Encuesta.idEnc = Asignar.idEnc
    INNER JOIN Respuesta on Asignar.idAsig = Respuesta.idAsig
    WHERE resultado =1";
    $query = mysqli_query($enlace, $sql);
    $total = mysqli_fetch_assoc($query);
    $pp1 = $total['promedio'];
    $epp1 = '';

    if ($pp1 >= 1 && $pp1 <= 1.9) {
        $epp1 = 'Muy Insatisfactorio';
    } elseif ($pp1 >= 2 && $pp1 <= 2.9) {
        $epp1 = 'Insatisfactorio';
    } elseif ($pp1 >= 3 && $pp1 <= 3.9) {
        $epp1 = 'Neutral';
    } elseif ($pp1 >= 4 && $pp1 <= 4.9) {
        $epp1 = 'Satisfactorio';
    } elseif ($pp1 >= 5) {
        $epp1 = 'Muy Satisfactorio';
    }


    $sql = "SELECT Round(AVG(pregunta2),2) as promedio FROM encuesta 
    INNER JOIN Asignar on Encuesta.idEnc = Asignar.idEnc
    INNER JOIN Respuesta on Asignar.idAsig = Respuesta.idAsig
    WHERE resultado =1";
    $query = mysqli_query($enlace, $sql);
    $total = mysqli_fetch_assoc($query);
    $pp2 = $total['promedio'];
    $epp2 = '';

    if ($pp2 >= 1 && $pp2 <= 1.9) {
        $epp2 = 'Muy Insatisfactorio';
    } elseif ($pp2 >= 2 && $pp2 <= 2.9) {
        $epp2 = 'Insatisfactorio';
    } elseif ($pp2 >= 3 && $pp2 <= 3.9) {
        $epp2 = 'Neutral';
    } elseif ($pp2 >= 4 && $pp2 <= 4.9) {
        $epp2 = 'Satisfactorio';
    } elseif ($pp2 >= 5) {
        $epp2 = 'Muy Satisfactorio';
    }

    $sql = "SELECT ROUND(AVG(pregunta3), 2) AS promedio FROM encuesta 
    INNER JOIN Asignar ON Encuesta.idEnc = Asignar.idEnc
    INNER JOIN Respuesta ON Asignar.idAsig = Respuesta.idAsig
    WHERE resultado = 1";

    $query = mysqli_query($enlace, $sql);
    $total = mysqli_fetch_assoc($query);
    $pp3 = $total['promedio'];
    $epp3 = '';

    if ($pp3 >= 1 && $pp3 <= 1.9) {
        $epp3 = 'Muy Insatisfactorio';
    } elseif ($pp3 >= 2 && $pp3 <= 2.9) {
        $epp3 = 'Insatisfactorio';
    } elseif ($pp3 >= 3 && $pp3 <= 3.9) {
        $epp3 = 'Neutral';
    } elseif ($pp3 >= 4 && $pp3 <= 4.9) {
        $epp3 = 'Satisfactorio';
    } elseif ($pp3 >= 5) {
        $epp3 = 'Muy Satisfactorio';
    }

    $sql = "SELECT ROUND(AVG(pregunta4), 2) AS promedio FROM encuesta 
    INNER JOIN Asignar ON Encuesta.idEnc = Asignar.idEnc
    INNER JOIN Respuesta ON Asignar.idAsig = Respuesta.idAsig
    WHERE resultado = 1";

    $query = mysqli_query($enlace, $sql);
    $total = mysqli_fetch_assoc($query);
    $pp4 = $total['promedio'];
    $epp4 = '';

    if ($pp4 >= 1 && $pp4 <= 1.9) {
        $epp4 = 'Muy Insatisfactorio';
    } elseif ($pp4 >= 2 && $pp4 <= 2.9) {
        $epp4 = 'Insatisfactorio';
    } elseif ($pp4 >= 3 && $pp4 <= 3.9) {
        $epp4 = 'Neutral';
    } elseif ($pp4 >= 4 && $pp4 <= 4.9) {
        $epp4 = 'Satisfactorio';
    } elseif ($pp4 >= 5) {
        $epp4 = 'Muy Satisfactorio';
    }

    $sql = "SELECT ROUND(AVG(pregunta5), 2) AS promedio FROM encuesta 
    INNER JOIN Asignar ON Encuesta.idEnc = Asignar.idEnc
    INNER JOIN Respuesta ON Asignar.idAsig = Respuesta.idAsig
    WHERE resultado = 1";

    $query = mysqli_query($enlace, $sql);
    $total = mysqli_fetch_assoc($query);
    $pp5 = $total['promedio'];
    $epp5 = '';

    if ($pp5 >= 1 && $pp5 <= 1.9) {
        $epp5 = 'Muy Insatisfactorio';
    } elseif ($pp5 >= 2 && $pp5 <= 2.9) {
        $epp5 = 'Insatisfactorio';
    } elseif ($pp5 >= 3 && $pp5 <= 3.9) {
        $epp5 = 'Neutral';
    } elseif ($pp5 >= 4 && $pp5 <= 4.9) {
        $epp5 = 'Satisfactorio';
    } elseif ($pp5 >= 5) {
        $epp5 = 'Muy Satisfactorio';
    }

?>