<?php
        session_start();
        include 'controlador_conexion.php';

        $us = $_SESSION['usuario'];
        $sql = "SELECT idAlum FROM alumno WHERE correo = '$us';";
        $result = mysqli_query($enlace, $sql);
        $row = mysqli_fetch_assoc($result);
        $id = $row['idAlum'];

        $opcionSeleccionada = $_POST['radios'];
        $rec = $_POST['receta']; 

        echo $opcionSeleccionada;
        echo $rec;
        echo $id;
        if(!empty($opcionSeleccionada)){
            $sql = "INSERT INTO calificacion (idCal ,Grado, idRec, idAlum) VALUES (0,'$opcionSeleccionada','$rec','$id')";
            $execute = mysqli_query($enlace, $sql);
            if($execute){
                echo '<script>alert("Calificación enviada");
                    window.location = "../VISTA/recetas.php";</script>';
            }else{ 
               echo '<script>alert("Error al enviar la calificación, inténtelo de nuevo");
                    window.location = "../VISTA/recetas.php";</script>';
            }
        }else{
            //comentario vacio mandar un alert
            echo '<script>alert("No selecciono ninguna opción, inténtelo de nuevo");
                    window.location = "../VISTA/recetas.php";</script>';
        }
?>