<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reportes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
=    .company-name {
      font-style: italic;
    }
    .header-line {
      border-bottom: 1px solid #000;
      margin-bottom: 20px; 
    }
  </style>
</head>
<body>
    <?php
        include'controlador_conexion.php';
        date_default_timezone_set('America/Mexico_City');

        $diaSemana = [
            "Domingo", "Lunes", "Martes", "Miércoles",
            "Jueves", "Viernes", "Sábado"
        ];
        
        // Meses en español
        $meses = [
            "enero", "febrero", "marzo", "abril", "mayo", "junio",
            "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"
        ];
        
        $fecha = $diaSemana[date("w")] . ", " . date("j") . " de " . $meses[date("n") - 1] . " de " . date("Y");

        include 'controlador_estadisticos.php';
        //ALUMNOS
        $sql = "SELECT COUNT(*) as total FROM alumno";
        $query = mysqli_query($enlace, $sql);
        $total = mysqli_fetch_assoc($query);
        $alumnos = $total['total'];

        //RECETAS
        $sql = "SELECT COUNT(*) as total FROM receta";
        $query = mysqli_query($enlace, $sql);
        $total = mysqli_fetch_assoc($query);
        $recetas = $total['total'];

        //ENCUESTAS
        $sql = "SELECT COUNT(*) as total FROM encuesta 
        INNER JOIN Asignar on Encuesta.idEnc = Asignar.idEnc
        INNER JOIN Respuesta on Asignar.idAsig = Respuesta.idAsig
        WHERE resultado =1";
        $query = mysqli_query($enlace, $sql);
        $total = mysqli_fetch_assoc($query);
        $encuestas = $total['total'];

        $publicacionesHombres = 150; // Publicaciones de hombres
        $publicacionesMujeres = 100; // Publicaciones de mujeres    
    ?>
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <img src="http://<?php echo $_SERVER['HTTP_HOST'];?>/SistemaWeb/IMG/logo.png" alt="Logo de la empresa" class="img-fluid" width="120" height="120">
      </div>
      <div class="col-md-6 text-end mt-25">
        <h1 class="company-name"><i>noncore</i></h1>
        <p><?php echo $fecha?></p>
        <div class="header-line"></div>
      </div>
    </div>
  </div>

  <div class="container mt-4">
    <h2>Reporte de Alumnos y Publicaciones</h2>
    <div class="header-line"></div>
    <div class="row">
      <div class="col-md-6">
        <h3>Número de Alumnos</h3>
        <p>Total: <?php echo $alumnos; ?></p>
        <p>Hombres: <?php echo $masculino; ?></p>
        <p>Mujeres: <?php echo $femenino; ?></p>
      </div>
      <div class="col-md-6">
        <h3>Número de Publicaciones</h3>
        <p>Total: <?php echo $recetas; ?></p>
        <p>Publicaciones de Hombres: <?php echo $rmasculino; ?></p>
        <p>Publicaciones de Mujeres: <?php echo $rfemenino; ?></p>
      </div>
      <div class="header-line"></div>
      <h2>Reporte de encuestas contestadas</h2>
      <div class="header-line"></div>
      <div class="col-md-6">
        <h3>Número de encuestas contestadas</h3>
        <p>Total: <?php echo $encuestas; ?></p>
        <p>Promedio de nivel de satisfacción: <?php echo $pp1; ?> por lo tanto es <?php echo $epp1; ?></p>
        <p>Promedio de la calidad de la información:  <?php echo $pp2; ?> por lo tanto es <?php echo $epp2; ?></p>
        <p>Promedio de la facilidad de uso: <?php echo $pp3; ?> por lo tanto es <?php echo $epp3; ?></p>
        <p>Promedio de la calificación a la página:  <?php echo $pp4; ?> por lo tanto es <?php echo $epp4; ?></p>
        <p>Promedio de recomendación a terceros: <?php echo $pp5; ?> por lo tanto es <?php echo $epp5; ?></p>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php 
    $html = ob_get_clean();
    //echo $html; 
    //C:\xampp\htdocs\SistemaWeb\LIBRERIAS\dompdf
    require_once '../../../LIBRERIAS/dompdf/autoload.inc.php';
    use Dompdf\Dompdf;
    $dompdf = new Dompdf();

    $options = $dompdf->getOptions();
    $options->set(array('isRemoteEnabled'=>true));
    $dompdf->setOptions($options);

    $dompdf->loadHtml($html);
    $dompdf->setPaper('letter');
    $dompdf->render();
    //$output = $dompdf->output();
    $dompdf->stream("Reporte.pdf", array("Attachment" => true));
?>
