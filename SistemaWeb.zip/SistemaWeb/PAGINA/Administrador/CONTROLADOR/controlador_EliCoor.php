<?php
    include 'controlador_conexion.php';
    $corre = $_POST['correo'];

        $sql = mysqli_query($enlace, "DELETE FROM coordinador WHERE cor = '$corre'");
        if($sql == true){
            echo '<script>alert("Eliminación exitosa");
            window.location = "../VISTA/administrarCoor.php";</script>';
       }else{
            echo '<script>alert("Falló");
            window.location = "../VISTA/administrarCoor.php";</script>';
        }
    
?>