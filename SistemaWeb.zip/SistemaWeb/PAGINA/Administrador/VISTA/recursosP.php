<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form action="../CONTROLADOR/controlador_subirCalP.php" method="POST">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-secondary">
                <input type="radio" name="radios" value="1" autocomplete="off">
                <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
            </label>
            <label class="btn btn-secondary">
                <input type="radio" name="radios" value="2" autocomplete="off">
                <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
            </label>
            <label class="btn btn-secondary">
                <input type="radio" name="radios" value="3" autocomplete="off">
                <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
            </label>
            <label class="btn btn-secondary">
                <input type="radio" name="radios" value="4" autocomplete="off">
                <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
            </label>
            <label class="btn btn-secondary">
                <input type="radio" name="radios" value="5" autocomplete="off">
                <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
            </label>
            <input name="receta" hidden value="<?=$datos->idRec?>"></input>
            <button Class="btn btn-primary" type="submit">Enviar</button>
        </div>
    </form>
    <script>
        const radioButtons = document.querySelectorAll('input[name="radios"]');
        radioButtons.forEach(button => {
        button.addEventListener('change', function() {
            if (this.checked) {
            const images = document.querySelectorAll('.btn-secondary img');
            images.forEach(img => {
                img.src = (img.parentElement.querySelector('input[name="radios"]:checked') !== null) ? '../../../IMG/estrella.png' : '../../../IMG/vacio.png';
            });
            }
        });
        });
    </script>
</body>
</html>