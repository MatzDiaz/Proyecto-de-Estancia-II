<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head> 
    <meta charset="UTF-8">
    <title>Administrar recetas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/5.0.0-beta2/css/bootstrap.min.css">
    <style>
        /* Personaliza el contorno del formulario */
        .custom-form {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
        }

        /* Reduce el tamaño del espacio y la fuente */
        .custom-form .form-label,
        .custom-form .form-control {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .custom-form .form-control {
            padding: 5px 10px;
        }

        .btn-secondary {
            background-color: transparent; 
            border: none; 
        }
        .btn-secondary:hover{
            background-color: transparent; 
            border: none; 
        }
        .btn-secondary:hover img {
            content: url('../../../IMG/estrella.png');
        }
        .btn-secondary.active {
            content: url('../../../IMG/estrella.png');
        }
    </style>
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const multimediaInput = document.getElementById('multimedia');
        
        multimediaInput.addEventListener('dragover', (e) => {
            e.preventDefault();
        });

        multimediaInput.addEventListener('drop', (e) => {
            e.preventDefault();
            const files = e.dataTransfer.files;
        });
    </script>

    <!--Obtener las recetas-->
    <?php   
        include '../CONTROLADOR/controlador_conexion.php';
        //obtener el id
        $correo = $_SESSION['usuario'];
        $sql = "SELECT idAlum FROM alumno WHERE correo = '$correo';";
        $result = mysqli_query($enlace, $sql);
        $row = mysqli_fetch_assoc($result);
        $id = $row['idAlum'];
        //consulta para mostrar recetas
        $sql = ("SELECT idRec, Titulo, FechaPub, Contenido, Multimedia, Nombre 
        FROM receta INNER JOIN alumno on receta.idAlum = alumno.idAlum WHERE estatus = 0");
        $consulta = mysqli_query($enlace, $sql);
        while($datos=$consulta->fetch_object()) {?>
        <div class="container mt-4  border mt-3 p-3">
         <div class="row">
        <!-- Nombre del alumno -->
        <input name="recet" value="<?=$datos->idRec?>" hidden></input>
        <div class="col-6">
            <?="<h2>$datos->Nombre</h2>";?>
        </div>
        <!-- Menú de tres puntos -->
        <div class="col-6 text-end">
            <div class="btn-group">
                <button type="button" class="btn btn-primary bg-white text-black" data-bs-toggle="modal" data-bs-target="#mdEliminar<?=$datos->idRec?>">Aceptar</button>
            </div>
        </div>
    </div>


    <!-- Fecha -->
    <div class="row mt-2">
        <div class="col">
                <?= "<p>$datos->FechaPub</p>" ?>
        </div>
    </div>

    <!-- Título de la publicación -->
    <div class="row mt-2">
        <div class="col">
            <?= "<center><h3>$datos->Titulo</h3></center>"?>
        </div>
    </div>

    <!-- Contenido -->
    <div class="row mt-2">
        <div class="col">
            <?="<p>$datos->Contenido</p>"?>
        </div>
    </div>

    <!--Parte de la imagen-->
    <div class="row mt-2">
        <div class="col-8">
            <img src="<?= $datos->Multimedia ?>" alt="Imagen de la publicación" class="img-fluid">
        </div>
        <div class="col-4">
            <!--Comentarios-->
            <p>Comentarios</p>
            <?php 
                $idReceta = $datos->idRec;
                $sql = $enlace->query("SELECT Comentario, Nombre
                        FROM receta 
                        INNER JOIN comentario ON receta.idRec = comentario.idRec 
                        INNER JOIN alumno ON alumno.idAlum = comentario.idAlum
                        WHERE receta.idRec = '$idReceta'");
                
                if ($sql) {
                    while ($datosComentario = $sql->fetch_object()) {
                        echo '<div class="container">';
                        echo '    <div class="row">';
                        echo '        <div class="col-2">';
                        echo '<i class="fas fa-user" style="font-size: 24px;"></i><img src="../../../IMG/p2.png" alt="Avatar" style="width: 48px; height: 48px;">';
                        echo '        </div>';
                        echo '        <div class="col-10">';
                        echo "            <!-- Nombre de usuario -->";
                        echo "            <h5>$datosComentario->Nombre</h5>";
                        echo "            <!-- Sección con texto -->";
                        echo "            <p>$datosComentario->Comentario</p>";
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                    }
                }
            ?>
            <!-- Botón de comentar -->
            <form action="../CONTROLADOR/controlador_subCom.php" method="POST">
                <input type="text" name="comentario"></input>
                <input name="receta" hidden value="<?=$datos->idRec?>"></input>
                <button type="submit" class="btn btn-primary bg-info">Agregar</button>
            </form>    
        </div>
    </div>

    <div class="row mt-2">
        <div class="col">
            <<!-- Opción para calificar -->
            <div class="btn-group" data-toggle="buttons">
                <label class="btn btn-secondary">
                    <input type="radio" name="radios" autocomplete="off">
                    <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="radios" autocomplete="off">
                    <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="radios" autocomplete="off">
                    <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="radios" autocomplete="off">
                    <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="radios" autocomplete="off">
                    <img src="../../../IMG/vacio.png" alt="Imagen 1"  class="img-fluid" width="20" height="20">
                </label>
            </div>
        </div>
    </div>
</div>

    <!-- Modal eliminar -->
    <form action="../CONTROLADOR/controlador_AcepReceta.php" method="POST">
            <div class="modal fade" id="mdEliminar<?=$datos->idRec?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Confirmaci&oacute;n</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="text" class="form-control" id="receta" name="receta" value="<?= $datos->idRec?>" hidden>
                        <p>¿Desea publicar la receta <?=$datos->Titulo?>?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Regresar</button>
                        <button type="submit" class="btn btn-primary bg-success" name="btnEliminar">Aceptar</button>
                    </div>
                    </div>
                </div>
            </div>
        </form>
        <!-- Modal editar -->
    <?php }?>
    <?php include 'AdmRecetasC.php';?>
</body>
</html>