<?php include '../CONTROLADOR/controlador_verifiaSes.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        *{
            font-family: 'Times New Roman', Times, serif;
        }

        .navbar-nav .nav-link {
            font-size: 16px;
        }

        .titulo{
            background: rgb(51, 255, 181);
        }
        .cabeza{
            background: rgb(51, 255, 181);
        }
    </style>
</head>
<body>

<!--Menu-->
        <nav class="navbar cabeza">
        <div class="container-fluid cabeza">
        <a class="navbar-brand" href="perfil.php"><img src="../../../IMG/usuario.png" width=40 >Administrador <br><label value="<?php echo $con?>"></label></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header titulo">
        <img src="../../../IMG/Logo.png" alt="Logo" width="40" height="30" class="d-inline-block"><h5 class="offcanvas-title" id="offcanvasNavbarLabel">noncore</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-1">
                <li class="nav-item  mb-50">
                <a class="navbar-brand" aria-current="page" href="principal.php">
                    <img src="../../../IMG/casa.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Inicio</a>
                </li>
                <br>
                <li class="nav-item">
                    <a class="navbar-brand" aria-current="page" href="administrarAlum.php"><img src="../../../IMG/grupo.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Gesti&oacute;n de alumnos</a>
                </li>
                <br>
                <li class="nav-item">
                <a class="navbar-brand" aria-current="page" href="administrarCoor.php"><img src="../../../IMG/grupo.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Gesti&oacute;n de coordinadores</a>
                </li>
                <br>
                <li class="nav-item">
                    <a class="navbar-brand" aria-current="page" href="recetas.php"><img src="../../../IMG/receta.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Mis recetas</a>
                </li>
                <br>
                <li class="nav-item">
                <a class="navbar-brand" aria-current="page" href="encuesta.php"><img src="../../../IMG/lista.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Gesti&oacute;n de encuestas</a>
                </li> 
                <br>
                <li class="nav-item">
                <a class="navbar-brand" aria-current="page" href="AdmRecetas.php"><img src="../../../IMG/aceptar.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Administrar recetas</a>
                </li>
                <br>
                <li class="nav-item">
                <a class="navbar-brand" aria-current="page" href="estadisticos.php"><img src="../../../IMG/estadistica.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Estad&iacute;sticos</a>
                </li>
                <br>
                <li class="nav-item">
                <a class="navbar-brand" aria-current="page" href="respaldo.php"><img src="../../../IMG/copia.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    Copia de seguridad</a>
                </li>
                <li>
                    <br>
                    <br>
                    <br>
                    <br>
                <form action="../CONTROLADOR/controlador_cerrar.php" method="post">
                    <center><button type="submit" class="btn btn-danger">Cerrar Sesión</button></center>
                </form>
                </li>
            </ul>
        </div>

        </div>
    </div>
    <!--Barra busqueda-->
    <div class="container">
            <form class="d-flex ms-auto" role="search">
                <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">
                    <img src="../../../IMG/buscar.png" width="40" alt="Buscar">
                </button>
            </form>
        </div>
    </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoJtKh7z7lGz7fuP4F8nfdFvAOA6Gg/z6Y5J6XqqyGXYM2ntXw/XNdnjGP9l8gpgjjyl/5DmkUuHg/V48L+xnDJFdLVUvQpU2jPZzf+dPp2t4N+KDp6r2gNg00tJKmDc1X4TfPtK413qV2D2O2Tp/0/CnqmJszLfUz" crossorigin="anonymous"></script>
</body>
</html>