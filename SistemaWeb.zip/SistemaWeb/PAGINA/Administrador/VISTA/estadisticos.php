<?php include 'header.php'; ?>
<?php include '../CONTROLADOR/controlador_estadisticos.php'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Panel de control</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      //graficas de alumnos
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Hombres', <?=$masculino?>],
          ['Mujeres', <?=$femenino?>],
        ]);

        var options = {
          title: 'Número de estudiantes por género'
        };

        var chart = new google.visualization.PieChart(document.getElementById('alumnos'));

        chart.draw(data, options);
      }
       
      //grafica grado de satisfaccion
    google.charts.load('current', {packages: ['corechart', 'bar']});
    google.charts.setOnLoadCallback(drawBasic);     
    function drawBasic() {

    var data = google.visualization.arrayToDataTable([
    ['grado', ' respuestas',],
    ['Muy insatisfecho',<?=$muyin?> ],
    ['insatisfecho',<?=$insatisfecho?> ],
    ['Neutral', <?=$neutro?>],
    ['Satisfecho', <?=$satisfecho?>],
    ['Muy satisfecho', <?=$muysat?>]
    ]);

    var options = {
    title: 'Grado de satisfacción de los alumnos',
    chartArea: {width: '50%'},
    hAxis: {
        title: 'Total de respuestas',
        minValue: 0
    },
    };

    var chart = new google.visualization.BarChart(document.getElementById('chart_div'));

    chart.draw(data, options);
    } 
    </script>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      //graficas de alumnos
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Recetas por hombres', <?=$rmasculino?>],
          ['Recetas por mujeres', <?=$rfemenino?>],
        ]);

        var options = {
          title: 'Recetas publicadas por género'
        };

        var chart = new google.visualization.PieChart(document.getElementById('recetas'));

        chart.draw(data, options);
      } 
    </script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Pregunta', 'Promedio'],
          ['Promedio de nivel de satisfacción', <?=$pp1?>],
          ['Promedio de la calidad de la información', <?=$pp2?>],
          ['Promedio de la facilidad de uso', <?=$pp3?>],
          ['Promedio de la calificación a la página', <?=$pp4?>],
          ['Promedio de recomendación a terceros', <?=$pp5?>]]);

        var options = {
          title: 'Promedio de las encuestas',
          legend: { position: 'none' },
        };

        var chart = new google.visualization.Histogram(document.getElementById('promedio'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <!--primer grafico-->
    <div id="alumnos" style="width: 900px; height: 500px;"></div>
    <!--segundo grafico-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <div id="chart_div"></div>
    <!--Cuarto grafico-->
    <div id="recetas" style="width: 900px; height: 500px;"></div>
    <!--Tercer grafico-->
    <div id="promedio" style="width: 900px; height: 500px;"></div>
    <br>
    <br>
    <div class="container">
      <div class="row justify-content-center">
        <form id="printForm" class="d-flex justify-content-center" action="../CONTROLADOR/controlador_reportes.php">
          <button type="submit" class="btn btn-primary bg-danger">Imprimir reportes</button>
        </form>
      </div>
    </div>
    <br>
  </body>
</html>