<?php include 'headerC.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <title>Encuesta de Satisfacción</title>
</head>
<body>
<?php include'../CONTROLADOR/controlador_buscaAlu.php'?>
<div class="container">
    <div class="col-9 p-4">
        <table class="table">
            <thead class="bg-info">
                <tr>
                <th scope="col">ID</th>
                <th scope="col">NOMBRE</th>
                <th scope="col">FECHA</th>
                <th scope="col">ESTATUS</th>
                </tr>
            </thead>
            <tbody>
            <?php
                include '../CONTROLADOR/controlador_conexion.php';
                $sql = $enlace->query("SELECT Asignar.idAsig, Nombre, Resultado, FechaEn FROM Asignar
                                    INNER JOIN Alumno ON alumno.idalum = asignar.idalum
                                    INNER JOIN Respuesta ON Respuesta.idAsig = Asignar.idAsig");
                while ($datos = $sql->fetch_object()) {
                    ?>
                    <tr>
                        <td name="id"><?= $datos->idAsig ?></td>
                        <td><?= $datos->Nombre ?></td>
                        <td><?= $datos->FechaEn ?></td>
                        <td>
                            <?php if ($datos->Resultado == 1) {
                                echo "Contestado";
                            } else {
                                echo "Pendiente";
                            } ?>
                        </td> 
                    </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>